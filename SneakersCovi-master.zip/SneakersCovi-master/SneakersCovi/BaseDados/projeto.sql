-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Tempo de geração: 12-Dez-2023 às 15:34
-- Versão do servidor: 5.7.39
-- versão do PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `projeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created`, `modified`) VALUES
(1, 'Sapatilhas de Basquetebol', 'Esta categoria é dedicada a sapatilhas de basquetebol ', '2022-05-26 09:14:01', '2022-05-26 09:14:41'),
(2, 'Sapatilhas de Futebol', 'Esta categoria é dedicada a sapatilhas de futebol.', '2022-05-26 09:14:46', '2022-05-26 09:15:36'),
(3, 'Sapatilhas de Dia à Dia', 'Esta categoria é dedicada a sapatilhas do dia à dia ', '2022-05-26 09:16:24', '2022-05-26 09:17:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'alex', 'alex');

-- --------------------------------------------------------

--
-- Estrutura da tabela `multi_login`
--

CREATE TABLE `multi_login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `multi_login`
--

INSERT INTO `multi_login` (`id`, `username`, `email`, `user_type`, `password`) VALUES
(1, 'jorge', 'jorge@gmail.com', 'user', 'jorge123'),
(2, 'antonio', 'antonio@gmail.com', 'user', 'toni');

-- --------------------------------------------------------

--
-- Estrutura da tabela `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category_id`, `created`, `modified`) VALUES
(1, 'SAPATILHAS TRAE YOUNG 1', 'SAPATILHAS COM ASSINATURA DO TRAE YOUNG FEITAS EM PARTE COM CONTEÚDO RECICLADO.', '130', 1, '2022-05-26 09:28:08', '2022-05-26 09:33:29'),
(2, 'Jordan Why Not .5?', 'O Russell Westbrook é veloz. Estas sapatilhas combinam com a sua velocidade com amortecimento modernizado, tração baseada em dados e um sistema de ajuste a todo o comprimento que permite manter o controlo. Com um look robusto e utilitário combinado com uma combinação intencional de cores e materiais, este modelo inspira-se nos fundamentos do lema \"Why Not?\" do Russel.', '139', 1, '2022-05-26 09:33:41', '2022-05-26 09:35:28'),
(3, 'SAPATILHAS  LA LAKERS', 'Estas botas de basquetebol têm uma sola com amortecimento em espuma injetada (EVA) que oferece um excelente conforto durante a prática.', '55', 1, '2022-05-26 09:36:01', '2022-05-26 09:38:04'),
(4, 'Zion 1 SP', 'Combinando uma personalidade humilde com capacidade atlética de outro mundo, o Zion dá o seu melhor no jogo, com calçado a combinar. As suas sapatilhas são leves, estáveis e fortes, com uma sola exterior resistente que adere ao campo. Ao mesmo tempo, o amortecimento Air confere um conforto macio por baixo do pé e a reatividade rápida que conheces e adoras.', '129', 1, '2022-05-26 09:38:15', '2022-05-26 09:39:05'),
(5, 'LeBron 19', 'O LeBron prospera quando o desafio é grande e a pressão está em alta. As LeBron 19 tiram partido dessa energia com um ajuste firme e um sistema de amortecimento modernizado.', '189', 1, '2022-05-26 09:39:15', '2022-05-26 09:40:19'),
(6, 'PREDATOR FREAK.1 ', 'CONTROLA AS PARTIDAS EM PISO MOLE COM ESTAS BOTAS DE CANO MÉDIO.', '110', 2, '2022-05-26 09:41:26', '2022-05-26 09:42:52'),
(7, 'Nike Mercurial 8 Elite FG', 'Desbloqueia a velocidade com as Nike Mercurial Superfly 8 Elite FG. Os blocos de cor nas laterais e no antepé destacam zonas estratégicas para fintas, passes e remates precisos. A placa inovadora proporciona reatividade imediata para viragens rápidas a alta velocidade.', '260', 2, '2022-05-26 09:43:49', '2022-05-26 09:44:32'),
(8, 'Future Z 1.3', 'Impressionantemente ágil e mais confortável do que nunca, a FUTURE é uma chuteira projetada para jogadores que comandam o campo com visão e habilidade.', '200', 2, '2022-05-26 09:44:42', '2022-05-26 09:48:17'),
(9, 'Nike Phantom GT2 ', 'Desenvolvidas com base nas Nike Phantom GT2 Dynamic Fit MG exibem um design e padrões modernizados, concebidos para permitir remates com elevada precisão. O sistema de laçada descentrada proporciona uma zona de remate lisa para remates, passes e fintas com precisão.', '90', 2, '2022-05-26 09:48:36', '2022-05-26 09:49:37'),
(10, 'Nike Tiempo Legend 9', 'Uma das nossas Tiempo mais leves até ao momento, as Nike Tiempo Legend 9 Pro AG-Pro permitem-te entrar na ofensiva com um design de baixo perfil reinventado para os avançados.A parte superior tem texturas em relevo, apoiadas por cápsulas de espuma macia para garantir fintas, passes e remates precisos, enquanto os pitões na parte inferior proporcionam tração para viragens rápidas e paragens súbitas.', '130', 2, '2022-05-26 10:29:25', '2022-05-26 10:29:52'),
(11, 'VANS TÉNIS OLD SKOOL', 'Conhecidos inicialmente como Vans #36, os Old Skool estrearam-se em 1977 com uma nova característica única: um rabisco aleatório desenhado pelo fundador Paul Van Doren, e originalmente referido como “jazz stripe”. Hoje, a famosa risca lateral tornou-se a marca inconfundível e instantaneamente reconhecível da marca Vans.', '90', 3, '2022-05-26 10:29:57', '2022-05-26 10:32:03'),
(12, 'Nike Go FlyEase', 'Quando pensas que já viste tudo, a Nike surpreende com uma forma totalmente nova e rápida de calçar as sapatilhas.Todo o calcanhar (incluindo a sola) das Nike Go FlyEase abre-se para permitir calçar as sapatilhas sem usar as mãos.Enfia o pé, faz pressão e já está!Tudo a postos. ', '129', 3, '2022-05-26 10:32:12', '2022-05-26 10:33:30'),
(13, 'SAPATILHAS PRIMEBLUE NMD_R1', 'Faz a mala, calça-te e deixa-te ir. As aventuras na cidade pedem estas sapatilhas NMD_R1. Uma atualização de sapatilhas de running aclamadas nos anos 80, estas sapatilhas modernas têm um topo em malha elástica e suave e amortecimento Boost com retorno de energia para conforto ao longo de todo o dia. Cores arrojadas e os icónicos elementos na entressola fazer um statement, para chegares com estilo a todo o lado onde vais.', '150', 3, '2022-05-26 10:34:07', '2023-12-12 11:54:27');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `multi_login`
--
ALTER TABLE `multi_login`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `multi_login`
--
ALTER TABLE `multi_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
